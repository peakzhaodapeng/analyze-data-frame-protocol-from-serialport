﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;//得有这个文件才能支持串口

namespace receiveBYtesTEST
{/*本程序能够解析a5 5a（帧头） 01（包号） 07 （字节数）01（有效数据） e8 f1（CRC_16 MODBUS）类型数据*/
    public partial class Form1 : Form
    {
        //private StringBuilder builder = new StringBuilder();//避免在事件处理方法中反复的创建，定义在函数外面
        private long received_cnt = 0;//接收计数
        
        private bool Listening = false;//是否执行完invoke等操作
        private bool closing_flag = false;//是否在关闭串口，执行Application.DoEvents,并阻止再次invoke
        private List<byte> buffer = new List<byte>(4096);//默认分配一页内存，并始终限值不能超过
        private byte[] binary_data_1 = new byte[7];//a5 5a（帧头） 01（包号） 07 （字节数）01（有效数据） e8 f1（CRC_16 MODBUS）
        public Form1()
        {
            InitializeComponent();
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;
            //禁用了所有的控件合法性检查
        }
        //public SerialPort serialPort;
       
        private void searchPortbutton1_Click(object sender, EventArgs e)
        {
            portNUMcomboBox1.Items.Clear();
            string[] ArrComPortsName = SerialPort.GetPortNames();//获取当前串口个数名称
            if (ArrComPortsName.Length != 0)
            {
                Array.Sort(ArrComPortsName);
            }
            for (int portNUM_cnt = 0; portNUM_cnt < ArrComPortsName.Length; portNUM_cnt++)
            {
                portNUMcomboBox1.Items.Add(ArrComPortsName[portNUM_cnt]);
            }
            portNUMcomboBox1.Text = ArrComPortsName[0];
        }

        private void openPortbutton2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                closing_flag = true;
                while (Listening) 
                    Application.DoEvents();
                serialPort1.Close();
            }
            else
            {
                serialPort1.PortName = portNUMcomboBox1.Text;/*测试代码*/
                serialPort1.BaudRate = 115200;  //转换为10进制
                serialPort1.DataBits = 8;
                serialPort1.StopBits = (StopBits)1;
                try
                {
                    serialPort1.Open();
                }
                catch(Exception ex)
                {
                    serialPort1=new SerialPort();
                    MessageBox.Show(ex.Message);
                }
            }
           
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (closing_flag) return;//如果正在关闭，忽略操作，直接返回，尽快的完成串口监听线程的一次循环
            try
            {
                int frame_head_position=0;
                Listening = true;//设置标记，说明我已经开始处理数据，一会要使用系统UI
                int num = serialPort1.BytesToRead;//先记录下来，避免某种原因，人为的原因，操作几次之间时间长，缓存不一致
                byte[]buf=new byte[num];//定义一个临时数组来存储当前来的串口数据
                received_cnt += num;//增加接收计数
                serialPort1.Read(buf,0,num);//读取缓冲数据
                /*协议解析*/
                bool data_1_cached = false;//缓存数据是否捕获到
                buffer.AddRange(buf);//数组里面的值，放入泛型集合list
                while (buffer.Count >= 4)
                {
                    if (buffer[0] == 0xa5 && buffer[1] == 0x5a)//检查是不是帧头
                    {
                        int len=buffer[3];//得到这一包数据的字节数，获取数据长度
                        if (buffer.Count < len) break;//数据不够的时候什么都不做，跳出去

                        byte CRC_L, CRC_H;//数据长度够了开始校验
                        byte Carry, n;
                        byte i = 0;
                        int sendbuf_length = len - 2;
                        CRC_L = 0xff;
                        CRC_H = 0xff;
                        while (sendbuf_length > 0)
                        {
                            CRC_L = (byte)(CRC_L ^ (buffer[i]));
                            for (n = 0; n < 8; n++)
                            {
                                Carry = (byte)(CRC_L & 1);
                                CRC_L >>= 1;

                                if ((CRC_H & 0x01) != 0)
                                    CRC_L = (byte)(CRC_L | 0x80);
                                CRC_H >>= 1;
                                if (Carry != 0)
                                {
                                    CRC_L ^= 0x01;
                                    CRC_H ^= 0xa0;
                                }
                            }
                            i++;
                            sendbuf_length--;
                        }
                        if (buffer[len - 2] != CRC_L || buffer[len - 1] != CRC_H)
                        {
                            buffer.RemoveAt(0);
                            frame_head_position = buffer.IndexOf(Convert.ToByte(0xa5));
                            buffer.RemoveRange(0, frame_head_position);//删除错误数据
                           // buffer.RemoveRange(0, len);//删除错误数据
                            continue;//进行下一次循环
                        }
                       
                           //至此已经找到了一条完整的数据，我们将数据直接分析，或者缓存起来一起分析，我们采取的办法是
                            //缓存一次，好处就是可以拿到最新的一包数据，不用再去找最新的数据了
                        buffer.CopyTo(0,binary_data_1,0,len);
                        data_1_cached = true;
                            buffer.RemoveRange(0, len);
                            if (data_1_cached)//开始分析数据,如果还有其他的数据包在这里增加就可以了
                            {
                                string data = binary_data_1[4].ToString();

                                this.Invoke((EventHandler)(delegate 
                                { 
                                    receiveDATAtextBox1.Text += data;
                                     newestFrame_textBox1.Text = data;
                                }));

                            }
                    
                    }
                    else//如果数据不是帧头则删除最开头的数据，仅仅是删除一个字节，一直等到正确的帧头过来
                    {
                        buffer.RemoveAt(0);
                    }
                }
                

            }
            finally
            {
                Listening = false;//我用完了，可以关闭串口了
            }
         
        }

        private void closePort_button3_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
          
        }
       
        
        private void readBufferbutton4_Click(object sender, EventArgs e)
        {
            
            int count = serialPort1.BytesToRead;  // 串口的接收缓冲区，
            Byte[] dataBuff = new Byte[count];
            serialPort1.Read(dataBuff, 0, count);  //串口读取接收缓存区的数据
        }

        private void clearTextboxbutton5_Click(object sender, EventArgs e)
        {
            receiveDATAtextBox1.Clear();
        }

        private void levelUpThresholdbutton6_Click(object sender, EventArgs e)
        {
            serialPort1.ReceivedBytesThreshold += 2;
        }
    }
}
